﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examensb
{
    class NEnt
    {
    
        private int n;


        public NEnt()
        {
            n = 0;
        }


        public void cargar(int dato)
        {
            n = dato;
        }



        
    }
}
