﻿namespace Examensb
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.pRACTICO2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eJERCICIO1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.eJERCICIO2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mENUV1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cargarRndToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.descargarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mENUV2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.descargarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(79, 254);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(570, 20);
            this.textBox6.TabIndex = 13;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(79, 202);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(570, 20);
            this.textBox5.TabIndex = 11;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(79, 151);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(570, 20);
            this.textBox4.TabIndex = 10;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(549, 92);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 9;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(321, 92);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(79, 92);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 7;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pRACTICO2ToolStripMenuItem,
            this.mENUV1ToolStripMenuItem,
            this.mENUV2ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(760, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // pRACTICO2ToolStripMenuItem
            // 
            this.pRACTICO2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eJERCICIO1ToolStripMenuItem1,
            this.eJERCICIO2ToolStripMenuItem1});
            this.pRACTICO2ToolStripMenuItem.Name = "pRACTICO2ToolStripMenuItem";
            this.pRACTICO2ToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.pRACTICO2ToolStripMenuItem.Text = "EXAMEN";
            // 
            // eJERCICIO1ToolStripMenuItem1
            // 
            this.eJERCICIO1ToolStripMenuItem1.Name = "eJERCICIO1ToolStripMenuItem1";
            this.eJERCICIO1ToolStripMenuItem1.Size = new System.Drawing.Size(141, 22);
            this.eJERCICIO1ToolStripMenuItem1.Text = "PREGUNTA 1";
            this.eJERCICIO1ToolStripMenuItem1.Click += new System.EventHandler(this.eJERCICIO1ToolStripMenuItem1_Click);
            // 
            // eJERCICIO2ToolStripMenuItem1
            // 
            this.eJERCICIO2ToolStripMenuItem1.Name = "eJERCICIO2ToolStripMenuItem1";
            this.eJERCICIO2ToolStripMenuItem1.Size = new System.Drawing.Size(141, 22);
            this.eJERCICIO2ToolStripMenuItem1.Text = "PREGUNTA 2";
            this.eJERCICIO2ToolStripMenuItem1.Click += new System.EventHandler(this.eJERCICIO2ToolStripMenuItem1_Click);
            // 
            // mENUV1ToolStripMenuItem
            // 
            this.mENUV1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cargarRndToolStripMenuItem,
            this.descargarToolStripMenuItem});
            this.mENUV1ToolStripMenuItem.Name = "mENUV1ToolStripMenuItem";
            this.mENUV1ToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.mENUV1ToolStripMenuItem.Text = "MENU V1";
            // 
            // cargarRndToolStripMenuItem
            // 
            this.cargarRndToolStripMenuItem.Name = "cargarRndToolStripMenuItem";
            this.cargarRndToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cargarRndToolStripMenuItem.Text = "cargar rnd";
            this.cargarRndToolStripMenuItem.Click += new System.EventHandler(this.cargarRndToolStripMenuItem_Click);
            // 
            // descargarToolStripMenuItem
            // 
            this.descargarToolStripMenuItem.Name = "descargarToolStripMenuItem";
            this.descargarToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.descargarToolStripMenuItem.Text = "descargar";
            this.descargarToolStripMenuItem.Click += new System.EventHandler(this.descargarToolStripMenuItem_Click);
            // 
            // mENUV2ToolStripMenuItem
            // 
            this.mENUV2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.descargarToolStripMenuItem1});
            this.mENUV2ToolStripMenuItem.Name = "mENUV2ToolStripMenuItem";
            this.mENUV2ToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.mENUV2ToolStripMenuItem.Text = "MENU V2";
            // 
            // descargarToolStripMenuItem1
            // 
            this.descargarToolStripMenuItem1.Name = "descargarToolStripMenuItem1";
            this.descargarToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.descargarToolStripMenuItem1.Text = "descargar";
            this.descargarToolStripMenuItem1.Click += new System.EventHandler(this.descargarToolStripMenuItem1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 376);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem pRACTICO2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eJERCICIO1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem eJERCICIO2ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mENUV1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cargarRndToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem descargarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mENUV2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem descargarToolStripMenuItem1;
    }
}

